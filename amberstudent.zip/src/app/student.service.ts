import { Injectable, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Student } from './student/student.interface';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StudentService implements OnInit{
  url:string="http://localhost:3000/studentsData";
  filtereddata:Student[];
  students:Student[];
  constructor(private http:HttpClient) { }
  
  ngOnInit(){
  }
  getStudents():Observable<Student[]>{
    return this.http.get<Student[]>(this.url);
    }
    addStudent(student:Student){
      return this.http.post(this.url,student);
    }
}
