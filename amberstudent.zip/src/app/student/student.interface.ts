export interface Student
{
    id:Number;
    name:string;
    age:number;
    gender:string;
    phone:number;
}