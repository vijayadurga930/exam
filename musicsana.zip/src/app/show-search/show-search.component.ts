import { Component, OnInit } from '@angular/core';
import { AlbumsService } from '../albums.service';
import { Album } from '../album';

@Component({
  selector: 'app-show-search',
  templateUrl: './show-search.component.html',
  styleUrls: ['./show-search.component.css']
})
export class ShowSearchComponent implements OnInit {
filteredValue:Album[];
  constructor(private service:AlbumsService) { }

  ngOnInit() {
    this.filteredValue=this.service.getFilter();
  }

}
