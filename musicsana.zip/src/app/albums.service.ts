import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Album } from './album';

@Injectable({
  providedIn: 'root'
})
export class AlbumsService {
url:string="http://localhost:3300/musicdetails";
filterAlbum:Album[];
  constructor(private http:HttpClient) { }
  get()
  {
    return this.http.get<Album[]>(this.url);
  }
  delete(album:Album)
  {
    return this.http.delete<Album[]>(this.url+"/"+album.id);
  }
  getById(id:number)
  {
    return this.http.get<Album>(this.url+"/"+id);
  }
  update(album:Album)
  {
    return this.http.put(this.url+"/"+album.id,album);
  }
  add(album:Album){
    return this.http.post(this.url,album);
  }
  setData(albumsearch:Album[])
  {
    this.filterAlbum=albumsearch;
    return this.http.get<Album[]>(this.url);

  }
  getFilter(){
    return this.filterAlbum;
  }

}
