import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddalbumComponent } from './addalbum/addalbum.component';
import { AlbumlistComponent } from './albumlist/albumlist.component';
import { AlbumsService } from './albums.service';
import {FormsModule} from '@angular/forms';
import{ HttpClientModule} from '@angular/common/http';
import { UpdatealbumComponent } from './updatealbum/updatealbum.component';
import { SearchComponent } from './search/search.component';
import { ShowSearchComponent } from './show-search/show-search.component'

@NgModule({
  declarations: [
    AppComponent,
    AddalbumComponent,
    AlbumlistComponent,
    UpdatealbumComponent,
    SearchComponent,
    ShowSearchComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [AlbumsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
