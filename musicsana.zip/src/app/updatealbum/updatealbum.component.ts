import { Component, OnInit } from '@angular/core';
import { Album } from '../album';
import { AlbumsService } from '../albums.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-updatealbum',
  templateUrl: './updatealbum.component.html',
  styleUrls: ['./updatealbum.component.css']
})
export class UpdatealbumComponent implements OnInit {
AlbumData:Album={"id":0,"title":'',"price":0,"artist":''};

  constructor(private service:AlbumsService,private router:Router,private route:ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe((params)=>{this.service.getById(params['id']).subscribe((result)=>{this.AlbumData=result;})})
  }
  update()
  {
    this.service.update(this.AlbumData).subscribe((data)=>{this.router.navigate(['albumlist']);});
  }


}
