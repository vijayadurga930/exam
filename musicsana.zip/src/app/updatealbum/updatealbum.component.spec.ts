import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatealbumComponent } from './updatealbum.component';

describe('UpdatealbumComponent', () => {
  let component: UpdatealbumComponent;
  let fixture: ComponentFixture<UpdatealbumComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdatealbumComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatealbumComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
