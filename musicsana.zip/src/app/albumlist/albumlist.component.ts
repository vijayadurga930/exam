import { Component, OnInit } from '@angular/core';
import { AlbumsService } from '../albums.service';
import { Album } from '../album';

@Component({
  selector: 'app-albumlist',
  templateUrl: './albumlist.component.html',
  styleUrls: ['./albumlist.component.css']
})
export class AlbumlistComponent implements OnInit {
albumData:Album[];
//{"id":0,"title":'',"price":0,"artist":''};
  constructor(private service:AlbumsService) { }

  ngOnInit() {
    this.service.get().subscribe((data)=>{this.albumData=data});console.log(this.albumData);
  }
delete(album:Album)
{
  this.service.delete(album).subscribe((data)=>{this.albumData=this.albumData.filter(c=>c!==album)});};

}
