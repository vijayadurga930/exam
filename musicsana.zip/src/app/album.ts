export class Album {
    id:number;
    title:string;
    price:number;
    artist:string;
}
