import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AlbumlistComponent } from './albumlist/albumlist.component';
import { AddalbumComponent } from './addalbum/addalbum.component';
import { UpdatealbumComponent } from './updatealbum/updatealbum.component';
import { SearchComponent } from './search/search.component';
import { ShowSearchComponent } from './show-search/show-search.component';


const routes: Routes = [
  {path:'',redirectTo:'albumlist',pathMatch:'full'},
  {path:'albumlist',component:AlbumlistComponent},
  {path:'addalbum',component:AddalbumComponent},
  {path:'albumlist/update/:id',component:UpdatealbumComponent},
  {path:'search',component:SearchComponent},
  {path:'showsearch',component:ShowSearchComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
