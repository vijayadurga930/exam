import { Component, OnInit } from '@angular/core';
import { AlbumsService } from '../albums.service';
import { Album } from '../album';
import { Router } from '@angular/router';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
searchItem:string='';
albumData:Album[];
searchedAlbumData:Album[];
  constructor(private service:AlbumsService,private router:Router) { }

  ngOnInit() {
    this.service.get().subscribe((data:Album[])=>{this.albumData=data});
    console.log(this.albumData);
  }
  searchAlbum(value:String){
    this.searchedAlbumData=this.albumData.filter(album=>album.title.toLowerCase().indexOf(value.toLowerCase())!==-1);
   this.service.setData(this.searchedAlbumData).subscribe((data)=>{this.router.navigate(['showsearch']);});
  }
        
  }


