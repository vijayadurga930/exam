import { Component, OnInit } from '@angular/core';
import { AlbumsService } from '../albums.service';
import { Album } from '../album';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addalbum',
  templateUrl: './addalbum.component.html',
  styleUrls: ['./addalbum.component.css']
})
export class AddalbumComponent implements OnInit {
  AlbumData:Album={"id":0,"title":'',"price":0,"artist":''};
  constructor(private service:AlbumsService,private router:Router) { }

  ngOnInit() {
  }
  add(){
    this.service.add(this.AlbumData).subscribe((data)=>{this.router.navigate(['albumlist']);});
  }

}
