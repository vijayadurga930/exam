import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchformComponent } from './searchform/searchform.component';
import { ProductlistComponent } from './productlist/productlist.component';


const routes: Routes = [
  {
    path : 'app-searchform',
    component : SearchformComponent
},
{
    path : 'app-productlist',
    component : ProductlistComponent
},
]
;

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
