import { Component, OnInit } from '@angular/core';
import { ServiceService, Products } from '../service.service';

@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  styleUrls: ['./productlist.component.css']
})
export class ProductlistComponent implements OnInit {

  service : ServiceService;
  p : Products[];



  constructor(service : ServiceService) {
    this.service = service;
   }

  ngOnInit() {
    this.service.fetchData();
    this.p = this.service.getData();
  }
}