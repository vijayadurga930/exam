import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  http : HttpClient;
  
  service : ServiceService;

  
  p : Products[] = [];
  

  
  constructor(http : HttpClient) {
    this.http = http;
   }

   fetch : boolean = false;

   fetchData(){
     this.http.get('./assets/Products.json').subscribe(
       data =>{
         if(!this.fetch){
           this.convert(data);
           this.fetch = true;
         }
       }
     )
   }

   convert(data : any){
    for(let d of data["Products"]){
      let p1 = new Products(d.id, d.name, d.price ,d.category);
      this.p.push(p1);
    }
  }

  getData() : Products[]{
    return this.p;
  }

  add(p : Products){
    let p1= new Products(p.id, p.name, p.price, p.category);
    this.p.push(p1);
  }

  products1: Array<Products>
 search(data):Products[] {
 this.products1=[];
 for(let p1 of this.p) {
 if(p1.id==data.id) {
 this.products1.push(p1);
 }
 }
 return this.products1;
 }
}


export class Products{
  id : number;
  name : string;
  price : number;
  category: string;
  constructor(id : number, name : string , price : number, category : string){
      this.id = id;
      this.name = name;
       this.price=price;
      this.category=category;
  }
}