import { Component, OnInit } from '@angular/core';
import { ServiceService, Products } from '../service.service';

@Component({
  selector: 'app-searchform',
  templateUrl: './searchform.component.html',
  styleUrls: ['./searchform.component.css']
})
export class SearchformComponent implements OnInit {

  service : ServiceService;
  p : Products[]=[];

  constructor(service: ServiceService) { 
    this.service=service;
  }

  ngOnInit() {
  }

  search(data) {
    this.p=this.service.search(data);
    }
}
