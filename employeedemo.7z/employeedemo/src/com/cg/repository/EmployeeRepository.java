package com.cg.repository;

import java.util.HashMap;

import com.cg.beans.Employee;

public class EmployeeRepository {
	public static HashMap<Integer,Employee> map=new HashMap<>();
	public  HashMap<Integer,Employee> getAllDetails(){
		
		map.put(101,new Employee(101, "vijaya","programmer",92000));
		map.put(102,new Employee(102, "jaya","clerk",32000));
		map.put(103,new Employee(103, "vijji","manager",72000));
		return map;

}
}
