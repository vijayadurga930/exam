package com.cg.presentataion;

import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import com.cg.beans.Employee;
import com.cg.service.EmployeeServiceImpl;
import com.cg.service.IEmployeeService;
import com.cg.utility.SortByDesignation;
import com.cg.utility.SortById;
import com.cg.utility.SortByName;
import com.cg.utility.SortBySalary;
/*
 * writing main method for displaying and taking inputs from user
 * 
 */
public class Main {

  public static void main(String[] args) {
	  
	Scanner scanner=new Scanner(System.in);
    		IEmployeeService service=new EmployeeServiceImpl();
    		/**
    		 * initializing flags and values.   
    		 */
   
    			
    			boolean choice=false;
    			boolean result=false;
    			boolean deleteFlag=false;
    			int option;
    			String choice2;  
    			int choiceoption = 0;
    		    
    		 
    		 do {
    			 /**
    			  * writing sub-menu for sorting after selecting sorting, 
    			  * it displays sorting menus
    			  */
			System.out.println("**MAIN MENU***");
			System.out.println("1.Sorting\n2.deletion \n 3. exit");
			choice=true;
			option=scanner.nextInt();
			switch (option) {
case 1:{

System.out.println("Enter Option \n1.SortByName \n2.SortBysalary \n3.SortById \n4.SortBydesignation");
  int option2=scanner.nextInt();
 switch(option2) {

 		case 1:{
				List<Employee> Employeelistbyname=service.getAllDetails();
				Collections.sort(Employeelistbyname, new SortByName());
				System.out.println(Employeelistbyname);
			}
			break;
			case 2:{

			List<Employee>  Employeelistbysalary=service.getAllDetails();
				Collections.sort(Employeelistbysalary, new SortBySalary());
				System.out.println(Employeelistbysalary);
			}
			break;
			case 3:{
				List<Employee> Employeelistbyid=service.getAllDetails();
				Collections.sort( Employeelistbyid, new SortById());
				System.out.println( Employeelistbyid);
			}break;
			case 4:{
				List<Employee>Employeelistbydesignation=service.getAllDetails();
				Collections.sort(Employeelistbydesignation, new SortByDesignation());
				System.out.println(Employeelistbydesignation);
			}break;
			    case 5:{

				System.out.println("Thanks for visiting......");
				System.exit(0);
					}break;
}break;
}
			case 2:{
				do {
					System.out.println("Enter employee Id to delete");
				scanner=new Scanner(System.in);
					int productId=scanner.nextInt();
					boolean status=service.delete(productId);
					if(status=true)
					{
						System.out.println( productId+ "  Deleted Successfully......");
						deleteFlag=true;
					}else {
						System.out.println("Id not available...");
						
					}
						
				}while(!deleteFlag);
				}break;
			case 3:{
				System.out.println("Thanks for visiting");
				System.exit(0);
			}break;
			default:
			{
				System.out.println("enter options only from 1,2& 3");
			}
			}
		}while(true);
	

}
}

