package com.cg.service;

import java.util.List;

import com.cg.beans.Employee;

public interface IEmployeeService {

	List<Employee> getAllDetails();

	boolean delete(int productId);

}
