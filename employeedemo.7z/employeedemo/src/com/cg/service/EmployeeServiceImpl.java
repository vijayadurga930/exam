package com.cg.service;

import java.util.List;

import com.cg.beans.Employee;
import com.cg.dao.EmployeedaoImpl;
import com.cg.dao.IEmployeeDao;

public class EmployeeServiceImpl implements IEmployeeService {
IEmployeeDao dao=new EmployeedaoImpl();
	@Override
	public List<Employee> getAllDetails() {
		
		return dao.getAllDetails();
	}

	@Override
	public boolean delete(int productId) {
		boolean status=dao.deleteCustomer(productId);
		if(status=true) {
			
			status=true;
		}
		
		
		return status;
	}

}
