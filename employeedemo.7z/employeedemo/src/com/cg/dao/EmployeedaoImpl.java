package com.cg.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.beans.Employee;
import com.cg.repository.EmployeeRepository;

public class EmployeedaoImpl implements IEmployeeDao{
EmployeeRepository repo=new EmployeeRepository();

boolean status=false;

@Override
	public List<Employee> getAllDetails() {
		
	Map<Integer, Employee> map = repo.getAllDetails();
	
		Collection<Employee> collection=map.values();
		
		List<Employee> employeelist=new ArrayList<>();
		
		employeelist.addAll(collection);
		
		Collections.sort(employeelist);
		
		return employeelist;
		
	}

	@Override
	public boolean deleteCustomer(int productId) {
		Map<Integer, Employee> map = repo.getAllDetails();
		
		Employee employee = map.remove(productId);
		if(map.get(productId)!=null)
		{
			
			System.out.println(map);
			status=true;
		}
		else {
			
			status=false;
		}
		    return status;
	}
		
	}


