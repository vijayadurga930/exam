package com.cg.dao;

import java.util.HashMap;
import java.util.List;

import com.cg.beans.Employee;

public interface IEmployeeDao {

	List<Employee> getAllDetails();

	boolean deleteCustomer(int productId);

}
